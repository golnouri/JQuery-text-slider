// textSlider, Mojtaba Golnouri Programming
$(document).ready(function(e) {
	var sliderCounter = 0;
	var sliderChecker = 3;
    $("#TwoNews").hide();
	$("#lblCounter").text("1");
	setInterval(function(){
		$("#lblCounter").text("2");
		$("#OneNews").hide();
		$("#TwoNews").fadeIn("slow");
		++sliderCounter;
		if(sliderCounter == sliderChecker)
		{
			$("#lblCounter").text("1")
			sliderCounter = 0;
			$("#TwoNews").hide();
			$("#OneNews").fadeIn("slow");
		}
	},5000);
	$("#lnkNext").click(function(){
		$("#lblCounter").text("2")
		$("#OneNews").hide();
		$("#TwoNews").fadeIn("slow");
	});
	$("#lnkBack").click(function(){
		$("#lblCounter").text("1")
		$("#TwoNews").hide();
		$("#OneNews").fadeIn("slow");
	});
});